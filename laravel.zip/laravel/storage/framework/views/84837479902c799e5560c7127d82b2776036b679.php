<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form id='doform'>
        <input type="text" name="gname"><br />
        <select name="cate" id="">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="小说"><?php echo e($v->c_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>
        <textarea name="desc" id="" cols="30" rows="10"></textarea><br />
        <input type="radio" name="hot" value="1"><input type="radio" name="hot" value="0">是否热卖<br />
        <input type="radio" name="is_sheif" value="1"><input type="radio" name="is_sheif" value="0">是否上架<br />
        <input type="button" value="提交" id="search">
    </form>
</body>
</html>
<script src="/js/jquery-3.1.1.min.js"></script>
<script>
$(function() {
  $('#search').click(function() {
    var t = $('#doform').serialize();
    $.ajax({
                url:"add_do",
                method:"post",
                data:t,
                success:function(res){
                    if(res==1){
                        alert('添加成功');
                            window.location.replace("list");
                    }else{
                        alert('添加失败')
                    }
                }
            });
   
  });
});

    
</script>