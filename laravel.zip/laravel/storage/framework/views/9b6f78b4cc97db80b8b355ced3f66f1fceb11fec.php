<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form id='doform'>
    <input type="hidden" name="id" value="<?php echo e($arr->id); ?>"><br />
        <input type="text" name="gname" value="<?php echo e($arr->gname); ?>"><br />
        <select name="cate" id="">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($v->c_name); ?>" <?php if($v->c_name==$arr->cate): ?> selected <?php endif; ?>><?php echo e($v->c_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>
        <textarea name="desc" id="" cols="30" rows="10"><?php echo e($arr->desc); ?></textarea><br />
        <?php if($arr->hot==1): ?>
            <input type="radio" name="hot" value="1" checked>
            <input type="radio" name="hot" value="0" >是否热卖<br />
        <?php else: ?>
            <input type="radio" name="hot" value="1">
            <input type="radio" name="hot" value="0" checked>是否热卖<br />
       <?php endif; ?>
       <?php if($arr->is_sheif==1): ?>
            <input type="radio" name="is_sheif" value="1" checked>
            <input type="radio" name="is_sheif" value="0">是否上架<br />
       <?php else: ?>
           <input type="radio" name="is_sheif" value="1">
           <input type="radio" name="is_sheif" value="0" checked>是否上架<br />
       <?php endif; ?>
            <input type="button" value="提交" id="search">
    </form>
</body>
</html>
<script src="/js/jquery-3.1.1.min.js"></script>
<script>
$(function() {
  $('#search').click(function() {
    var t = $('#doform').serialize();
    $.ajax({
                url:"upd_do",
                method:"post",
                data:t,
                success:function(res){
                    if(res==1){
                        alert('修改成功');
                            window.location.replace("list");
                    }else{
                        alert('修改失败')
                    }
                }
            });
   
  });
});

    
</script>