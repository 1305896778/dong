<?php

namespace App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\GoodsModel;
use App\models\CategoryModel;
use App\models\CartModel;
use App\models\OrderModel;
use Illuminate\Support\Facades\DB;
class PaymentController extends Controller
{
    //订单展示
    public function order(Request $request){
        $order_id=$request->input();
        $user_id=$request->session()->get('id');
        if($order_id){
            $arr=DB::table('order_goods')->where(['user_id'=>$user_id,'order_id'=>$order_id])->get();
            $price='';
            foreach($arr as $k=>$v){
                $price+=$v->shop_price;
            }
        }
        return view('payment.payment',['arr'=>$arr,'price'=>$price]);
    }
    //订单添加
    public function payment(Request $request){
        $id=$request->input('id');
        $user_id=$request->session()->get('id');
        if(empty($user_id)){
            return $info=[
                'status'=>0,
                'msg'=>'请先登录',
                'href'=>'/login'
            ];
        }
        $address=DB::table("address")->where(['user_id'=>$user_id,'is_default'=>0])->value('address_id');
        if(empty($address)){
            return $info=[
                'status'=>0,
                'msg'=>'请设置默认地址',
                'href'=>'/userpage'
            ];
        }
        $arr=CartModel::join('goods','goods.goods_id','=','goods_cart.goods_id')->whereIn('cart_id',$id)->get()->toArray();
        foreach($arr as $k=>$v){
           if($v['buy_num']>$v['goods_number']){
               $all[]=$v['goods_name'];
           }
           $order_price[]=$v['buy_num']*$v['goods_price'];
        }
        if(!empty($all)){
            $goods=implode(',',$all);
            return $info=[
                'status'=>1,
                'msg'=>$goods."库存不足",
            ];
        }
        //判断上架
        foreach($arr as $k=>$v){
            if($v['goods_shelf']!=1){
                $shelf[]=$v['goods_name'];
            }
        }
        if(!empty($shelf)){
            $goods_shelf=implode(',',$shelf);
            return $info=[
                'status'=>1,
                'msg'=>$goods_shelf."未上架",
            ];
        }
        $order_sn=date('YmdHis',time()).rand(1000,9999);
        $order_amount=array_sum($order_price);
        $data=[
            'order_sn'=>$order_sn,
            'order_amount'=>$order_amount,
            'order_status'=>1,
            'user_id'=>$user_id,
            'add_time'=>time(),
            'pay_status'=>1,
            'shipping_status'=>1,
            'order_pay_type'=>1,
            'pay_way'=>1,
            'address_id'=>$address
        ];
        $request=OrderModel::insertGetId($data);
        if($request){
            CartModel::whereIn('cart_id',$id)->update(['status'=>1]);
            foreach($arr as $k=>$v){
                $shop_price=$v['buy_num']*$v['goods_price'];
                $array[]=[
                    'order_id'=>$request,
                    'goods_id'=>$v['goods_id'],
                    'goods_name'=>$v['goods_name'],
                    'goods_img'=>$v['goods_img'],
                    'goods_sn'=>$v['goods_sn']?$v['goods_sn']:'',
                    'order_sn'=>$order_sn,
                    'buy_number'=>$v['buy_num'],
                    'shop_price'=>$shop_price,
                    'user_id'=>$user_id,
                    'c_time'=>time(),
                    'attr_values'=>''
                ];
            }
            DB::table('order_goods')->insert($array);
            return $info=[
                'status'=>2,
                'msg'=>"添加成功",
                'order_id'=>$request
            ];
        }
    }
    //默认地址展示
    public function addresses(Request $request){
        $user_id=$request->session()->get('id');
        $name=$request->session()->get('name');
        $address=DB::table('address')->where(['user_id'=>$user_id,'status'=>0])->get();
        return view('payment.addresses',['address'=>$address,'name'=>$name]);
    }
    //添加地址展示
    public function address(){
        return view('payment.address');
    }
    //添加地址执行
    public function doaddress(Request $request){
        $user_id=$request->session()->get('id');
        $data=$request->input();
        $data['user_id']=$user_id;
//        dump($data);die;
        if(!empty($data)){
            $id = Db::table('address')->insertGetId($data);
            if($id){
                $res=DB::table('address')->where('address_id','!=',$id)->where(['user_id'=>$user_id,'status'=>0])->update(['is_default'=>1]);
                if($res){
                    return $info=[
                        'status'=>1,
                        'msg'=>"新添加地址为默认地址",
                    ];
                }
            }
        }
    }
    //删除地址
    public function dodel(Request $request){
        $address_id=$request->input('address_id');
        if($address_id){
            $res=Db::table("address")->where('address_id',$address_id)->update(['status'=>1]);
            if($res){
                return $info=[
                    'status'=>1,
                    'msg'=>"删除成功呢",
                ];
            }
        }
    }
    //地址修改展示
    public function upd(Request $request){
        $id=$request->input('address_id');
        $arr=Db::table("address")->where('address_id',$id)->first();
        return view('payment.upd',['arr'=>$arr]);
    }
    //地址修改执行
    public function doupd(Request $request){
        $data=$request->input();
        $user_id=$request->session()->get('id');
        $id=$data['address_id'];
        $res = Db::table('address')->where(['user_id'=> $user_id,'address_id'=>$id])->update($data);
        if($res){
            if($res){
                return $info=[
                    'status'=>1,
                    'msg'=>"修改成功呢",
                ];
            }
        }
    }
    //点击设为默认
    public function updstatus(Request $request){
        $id=$request->input();
        $user_id=$request->session()->get('id');
        $res=DB::table("address")->where('address_id',$id)->update(['is_default'=>0]);
        if($res){
            $result=DB::table('address')->where('address_id','!=',$id)->where(['user_id'=>$user_id,'status'=>0])->update(['is_default'=>1]);
            if($result){
                return $info=[
                    'status'=>1,
                    'msg'=>"该地址已成功设为默认地址",
                ];
            }
        }
    }
    //我的潮购
    public function buyrecord(Request $request){
        $user_id=$request->session()->get('id');
        if(empty($user_id)){
            return $info=[
                'status'=>0,
                'msg'=>'请先登录'
            ];
        }
        $hot=GoodsModel::where('is_hot',1)->paginate(4);
        $arr=OrderModel::where('user_id',$user_id)->get()->toArray();
        foreach($arr as $k=>$v){
            $arr[$k]['time']=date("Ymd his",$v['add_time']);
        }
        return view('payment.buyrecord',['hot'=>$hot,'arr'=>$arr]);
    }
}
