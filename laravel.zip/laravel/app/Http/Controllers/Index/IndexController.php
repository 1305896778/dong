<?php
namespace App\Http\Controllers\Index;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\UserModel;
use App\models\GoodsModel;
use App\models\Code;
use Illuminate\Support\Facades\DB;
class IndexController extends Controller
{
    //首页展示
    public function index(Request $request){
        //猜你喜欢
        $arr=GoodsModel::where('goods_shelf',1)->paginate(6);
        //潮人推荐
        $data=GoodsModel::where('is_tell',1)->paginate(2);
        $count=DB::table('goods')->count();
        if($request->ajax()){
            return view('index.div',['arr'=>$arr]);
        }else{
            return view('index/index',['arr'=>$arr,'data'=>$data,'count'=>$count]);
        }
    }
    //注册展示
    public function register(){
        return view("index.register");
    }
    //登录展示
    public function login(){
        return view('index.login');
    }
    //我的潮购个人信息
    public function userpage(Request $request){
        $name=$request->session()->get('name');
        return view('index.userpage',['name'=>$name]);
    }
    //注册执行
    public function register_do(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $conpwd=$arr['conpwd'];
        $code=$arr['code'];
        $nowtime=time();
        //验证时间
//        DB::enableQueryLog();
        $usertime=Code::where(['user_tel'=>$tel,'is_code'=>1])->orderby('code_time','desc')->first();
        if(empty($usertime)){
            $info=[
                'status'=>0,
                'msg'=>'电话不一致'
            ];
            return $info;
        }
        $code_time=$usertime->code_time;
        if($nowtime>$code_time){
            Code::where(['user_tel'=>$tel,'user_code'=>$code])->update(['is_code'=>0]);
            $info=[
                'status'=>0,
                'msg'=>'验证码时间已过期'
            ];
            return $info;die;
        }
        if($usertime->user_code!=$code){
            $info=[
                'status'=>0,
                'msg'=>'验证码错误'
            ];
            return $info;
        }
        //确认密码验证
        if($pwd!=$conpwd){
            $data=array(
                'status'=>0,
                'msg'=>'密码不一致',
            );
            return $data;
        }
        //唯一性验证
        $user=UserModel::where(['user_tel'=>$tel])->first();
        if(!empty($user)&&!empty($user['user_pwd'])){
            $data=array(
                'status'=>0,
                'msg'=>'该手机号已注册',
            );
            return $data;
        }
        //验证码验证
        $userCode=Code::where(['user_tel'=>$tel,'user_code'=>$code,'code_time'=>['>',$nowtime]])->first();
        if($userCode){
            return $info=[
                'status'=>0,
                'msg'=>'验证码错误'
            ];
        };
        $array=array(
            'user_pwd'=>md5($pwd),
            'user_tel'=>$tel,
            'user_code'=>$code,
            'create_time'=>time(),
        );
        $res=UserModel::insert($array);
        if($res){
            Code::where(['user_tel'=>$tel,'user_code'=>$code])->update(['is_code'=>2]);
            $data=array(
                'status'=>2,
                'msg'=>'注册成功',
            );
            return $data;
        }
    }
    //登录执行
    public function dologin(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $where=[
            'user_tel'=>$tel,
            'user_pwd'=>md5($pwd),
        ];
        $data=UserModel::where($where)->first();
        if($data){
            $id=$data->user_id;
            $name=$data->user_tel;
            session(['id'=>$id,'name'=>$name]);
            return $info=[
                'status'=>1,
                'msg'=>'登录成功',
            ];
        }else{
            return $info=[
                'status'=>0,
                'msg'=>'登录失败',
            ];
        }
    }
    //验证码发送
    public function send(Request $request){
        $tel=$request->input('tel');
        $obj=new \send();
        $num=$obj->show($tel);
        $arr=[
            'user_tel'=>$tel,
            'user_code'=>$num,
            'code_time'=>time()+300,
            'is_code'=>1
        ];
        $res=Code::insert($arr);
        if($res){
            return $info=[
                'status'=>1,
                'msg'=>'获取验证码成功'
            ];
        }else{
            return $info=[
                'status'=>0,
                'msg'=>'获取验证码失败'
            ];
        };
    }
}
