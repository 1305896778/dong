<?php

namespace App\Http\Controllers\Cart;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\GoodsModel;
use App\models\CategoryModel;
use App\models\CartModel;
use Illuminate\Support\Facades\DB;
class CartController extends Controller
{
    //购物车展示
    public function cart(Request $request){
        $user_id=$request->session()->get('id');
        if(empty($user_id)){
            $buy_goods='';
            return $info=[
                'status'=>0,
                'msg'=>'请先登录'
            ];
        }else{
            return $info=[
                'status'=>1,
                'msg'=>'到购物车',
            ];
        }
    }
    //zhanshi
    public function zhanshi(Request $request){
        $user_id=$request->session()->get('id');
        if(empty($user_id)){
            return redirect('/login');
        }else{
            $buy_goods=CartModel::join('goods','goods.goods_id','=','goods_cart.goods_id')->where(['user_id'=>$user_id,'status'=>0])->get();
            $goodsLike=GoodsModel::where('is_hot',1)->paginate(4);
            return view('goods.cart',['buy_goods'=>$buy_goods,'goodsLike'=>$goodsLike]);
        }
    }
    //删除
    public function delcart(Request $request){
        $data=$request->input('data');
        if(!empty($data)){
            foreach($data as $k=>$v){
                $res=CartModel::where('cart_id',$v)->update(['status'=>2]);
            }
        }
        if($res){
            return $info=[
                'status'=>1,
                'msg'=>'删除成功'
            ];
        }else{
            return $info=[
                'status'=>0,
                'msg'=>'删除失败'
            ];
        }
    }
    //即点即改改变库存
    public function doupd(Request $request){
        $data=$request->input();
        $user_id=$request->session()->get('id');
        $id=$data['id'];
        $num=$data['num'];
        $where=[
            'user_id'=>$user_id,
            'status'=>0,
            'goods_id'=>$id
        ];
        $res=CartModel::where($where)->update(['buy_num'=>$num]);
        if($res){
            return $info=[
                'status'=>1,
                'msg'=>'修改成功'
            ];
        }else{
            return $info=[
                'status'=>0,
                'msg'=>'修改失败'
            ];
        }
    }
}











//    public function sarray(){
//        $arr=[
//            ['id'=>1,'name'=>'lisi','age'=>20],
//            ['id'=>2,'name'=>'lisi','age'=>50],
//            ['id'=>3,'name'=>'lisi','age'=>10],
//            ['id'=>4,'name'=>'lisi','age'=>9],
//            ['id'=>5,'name'=>'lisi','age'=>4],
//        ];
//
////        foreach($arr as $k=>$v){
////            $age[]=$v['age'];
////        }
////        sort($age);
////        foreach($arr as $k=>$v){
////            $arr[$k]['age']=$age[$k];
////        }
////        print_r($arr);
//        foreach($arr as $k=>$v){
//            $all[$v['age']]=$v;
//        }
//
//        foreach($arr as $k=>$v){
//           $age[]=$v['age'];
//       }
//        sort($age);
//        foreach($age as $k=>$v){
//            $arrhadel[]=$all[$v];
//        }
//        print_r($arrhadel);
//    }


