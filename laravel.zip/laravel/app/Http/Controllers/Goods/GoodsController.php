<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\GoodsModel;
use App\models\CategoryModel;
use App\models\CartModel;
use Illuminate\Support\Facades\DB;
class GoodsController extends Controller
{

    //所有商品展示
    public function goods(Request $request){
        $arr=CategoryModel::where('level',1)->get();
        //全部商品
        $cate=CategoryModel::get()->toArray();
        $cate_id=$request->input('cate_id');
        $id=$this->getcate($cate,$cate_id);
        $search=$request->input('search');
        //人气
        $goodshot=$request->input('shophot');
        //最新商品
        $goodsnew=$request->input('shopnew');
        //价格
        $goodsprice=$request->input('paixu');
        if($cate_id==0){
            $goods=GoodsModel::where('goods_shelf',1)->paginate(4);
            $count=DB::table('goods')->where('goods_shelf',1)->count();
            if(!empty($search)){
                $goods=GoodsModel::where('goods_name','like',"%$search%")->paginate(4);
            }
            if($goodshot=='人气'){
                $goods=GoodsModel::where('is_new',1)->paginate(4);
                $count=DB::table('goods')->where(['goods_shelf'=>1,'is_hot'=>1])->count();
            }
            if($goodsnew=='最新'){
                $goods=GoodsModel::where('is_new',1)->paginate(4);
                $count=DB::table('goods')->where(['goods_shelf'=>1,'is_new'=>1])->count();
            }
            if($goodsprice=='desc'){
                $goods=GoodsModel::where('goods_shelf',1)->orderBy('goods_price',$goodsprice)->paginate(4);
                $count=DB::table('goods')->where(['goods_shelf'=>1])->count();
            }else if($goodsprice=='asc'){
                $goods=GoodsModel::where('goods_shelf',1)->orderBy('goods_price',$goodsprice)->paginate(4);
                $count=DB::table('goods')->where(['goods_shelf'=>1])->count();
            }
        }else{
//            $cate_son=CategoryModel::where('pid',$cate_id)->pluck('cate_id')->toArray();
//            $c_id=CategoryModel::whereIn('pid',$cate_son)->pluck('cate_id');
            $goods=GoodsModel::whereIn('cate_id',$id)->paginate(4);
            $count=DB::table('goods')->whereIn('cate_id',$id)->count();
            if(!empty($search)){
                $goods=GoodsModel::whereIn('cate_id',$id)->where('goods_shelf','like',"%$search%")->paginate(4);
            }
            if($goodshot=='人气'){
//                DB::enableQueryLog();
                $goods=GoodsModel::whereIn('cate_id',$id)->where('is_hot',1)->paginate(4);
                $count=DB::table('goods')->whereIn('cate_id',$id)->where(['goods_shelf'=>1,'is_hot'=>1])->count();
//                dd(\DB::getQueryLog());
            }
            if($goodsnew=='最新'){
                $goods=GoodsModel::whereIn('cate_id',$id)->where('is_new',1)->paginate(4);
                $count=DB::table('goods')->whereIn('cate_id',$id)->where(['goods_shelf'=>1,'is_new'=>1])->count();
            }
            if($goodsprice=='desc'){
                $goods=GoodsModel::whereIn('cate_id',$id)->where('goods_shelf',1)->orderBy('goods_price',$goodsprice)->paginate(4);
                $count=DB::table('goods')->where(['goods_shelf'=>1])->count();
            }else if($goodsprice=='asc'){
                $goods=GoodsModel::whereIn('cate_id',$id)->where('goods_shelf',1)->orderBy('goods_price',$goodsprice)->paginate(4);
                $count=DB::table('goods')->where(['goods_shelf'=>1])->count();
            }
        }
        if($request->ajax()){
            return view('goods.goodsli',['goods'=>$goods]);
        }else{
            return view('goods.goods',['arr'=>$arr,'goods'=>$goods,'count'=>$count]);
        }
    }
    //商品详情展示
    public function content(Request $request){
        $goods_id=$request->input('id');
        $user_id=$request->session()->get('id');
        $content=GoodsModel::where(['goods_shelf'=>1,'goods_id'=>$goods_id])->first();
        if(empty($user_id)){
            $num='';
            $bnum=0;
        }else{
            $number=CartModel::where(['user_id'=>$user_id])->get();
            foreach($number as $k=>$v){
                $num[]=$v->buy_num;
            }
            if(!empty($num)){
                $bnum=array_sum($num);
            }else{
                $bnum=0;
            }
        }
        return view('goods.content',['content'=>$content,'bnum'=>$bnum]);
    }
//递归查询所有id
   function getcate($cate,$pid){
        static $arr=[];
        foreach($cate as $k=>$v) {
            if ($v['pid'] == $pid) {
                $arr[] = $v['cate_id'];
                $this->getcate($cate, $v['cate_id']);
            }
        }
        return $arr;
    }
    //添加购物车
    public function docart(Request $request){
        $goods_id=$request->input('goods_id');
        $user_id=$request->session()->get('id');
        if(!empty($goods_id)){
            if(empty($user_id)){
                return $info=[
                    'status'=>0,
                    'msg'=>'请登录后进行此操作'
                ];
            }else{
                $goods=GoodsModel::where(['goods_shelf'=>1,'goods_id'=>$goods_id])->first();
                $goods_number=$goods['goods_number'];
                if(empty($goods)){
                    return $info=[
                        'status'=>0,
                        'msg'=>'该商品已下架'
                    ];
                }else if($goods_number==0){
                    return $info=[
                        'status'=>0,
                        'msg'=>'该商品已经没有库存'
                    ];
                }else{
                    $buy_goods=CartModel::where(['user_id'=>$user_id,'goods_id'=>$goods_id])->first();
                    if(!empty($buy_goods)){
                        $arr=[
                            'buy_num'=>$buy_goods['buy_num']+1,
                            'ctime'=>time(),
                        ];
                        $res=CartModel::where(['user_id'=>$user_id,'goods_id'=>$goods_id])->update($arr);
                        if($res){
                            return $info=[
                                'status'=>1,
                                'msg'=>'商品已经成功加至购物车'
                            ];
                        }else{
                            return $info=[
                                'status'=>0,
                                'msg'=>'操作失败，请重试'
                            ];
                        }
                    }else{
                        $arr=[
                            'goods_id'=>$goods_id,
                            'user_id'=>$user_id,
                            'buy_num'=>1,
                            'ctime'=>time(),
                        ];
                        $res=CartModel::insert($arr);
                        if($res){
                            return $info=[
                                'status'=>1,
                                'msg'=>'商品已经成功加至购物车'
                            ];
                        }else{
                            return $info=[
                                'status'=>0,
                                'msg'=>'操作失败，请重试'
                            ];
                        }
                    }
                }
            }
        }
    }
}
