<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class GoodsModel extends Model
{
    public $timestamps=false;
    protected $table="goods";
}
