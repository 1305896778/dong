<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Goods extends Model
{
    //
    public $timestamps=false;
    protected $table="goods";
}
