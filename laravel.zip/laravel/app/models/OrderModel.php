<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class OrderModel extends Model
{
    public $timestamps=false;
    protected $table="order_info";
}
