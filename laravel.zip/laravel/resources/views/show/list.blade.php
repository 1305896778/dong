<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    #page ul li{
        list-style:none;
        float:left;
        padding:0 15px;
    }
</style>
<body>
<form>
    <select name="hot" id="hot">
        <option value="">---请选择---</option>
        <option value="1">是</option>
        <option value="0">否</option>
    </select>
    <select name="is_sheif" id="is_sheif">
        <option value="">---请选择---</option>
        <option value="1">是</option>
        <option value="0">否</option>
    </select>
    <input type="button" value="搜索" onclick="search()">
</form>
    <table border="1">
        <thead>
        <tr>
            <td>名称</td>
            <td>分类</td>
            <td>详情</td>
            <td>是否热卖</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
        </thead>
        <tbody>
        @foreach($arr as $k=>$v)
        <tr id="{{$v->id}}">
            <td class="name" gname="名称" value="{{$v->gname}}" g_id="{{$v->id}}">{{$v->gname}}</td>
            <td>{{$v->cate}}</td>
            <td>{{$v->desc}}</td>
            <td class="hot">{{$v->hot}}</td>
            <td class="sheif">{{$v->is_sheif}}</td>
            <td><a href="javascript:;" onclick="del({{$v->id}})">删除</a>|<a href="javascript:; onclick=upd({{$v->id}})">修改</a></td>
        </tr>
        @endforeach
        </tbody>
    </table>
<div id="page">{{ $arr->links() }}</div>
</body>

</html>

<script src="/js/jquery-3.1.1.min.js"></script>
<script>
 //删除
function del(id){
    if(confirm("是否删除")){
        $.post('del',{id:id},function(res){
            if(res==1){
                alert('删除成功');
                $('#'+id).empty();
                window.location.replace("list");
            }else{
                alert('删除失败');
            }
        })
    } 
}
//修改
function upd(id){
    if(confirm("是否修改")){
        window.location.replace("upd?id="+id);
    } 
}
//搜索
function search(){
    var hot=$("#hot").val();
    var is_sheif=$("#is_sheif").val();
    $.post("sousuo",{hot:hot,is_sheif:is_sheif},function(res){
        console.log(res);
        var arr='';
        $.each(res ,function(i,v){
            arr+="<tr>"
                +"<td>"+v.gname+"</td>"
                +"<td>"+v.cate+"</td>"
                +"<td>"+v.desc+"</td>"
                +"<td>"+v.hot+"</td>"
                +"<td>"+v.is_sheif+"</td>"
                +"<td>"+"<a href='javascript:;' onclick='del("+v.id+")'>删除</a>"+"</td>"
                +"<td>"+"<a href='javascript:;' onclick='upd("+v.id+")'>修改</a>"+"</td>"
                +"</tr>"
        })
        $("tbody").empty();
        $("tbody").html(arr);
        $("#page").empty();
        $("#page").html();
    })
}
//即点即改
$(function(){
    $(document).on('click','.name',function(){
        var _this=$(this);
        var value=_this.attr('value');
        _this.empty();
        _this.html("<input type='text' autofocus='autofocus' value="+value+" name='gname' class='foues'>");
    })
    $(document).on("blur",".foues",function(){
        var gname=$(this).val();
        var id=$(this).parent().attr('g_id');
        $.post("doupd",{gname:gname,id:id},function(res){
            if(res==1){
                alert('修改成功');
                location.href=("list");
            }else{
                alert('修改失败');
            }
        })
    })
})
</script>
