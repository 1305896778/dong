<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//添加展示
Route::get('show',"goods\GoodsController@show")
    // if($id<5){
    //     return view('show.show',['id'=>$id]);
    // }else{
    //     return redirect("http://www.baidu.com");
    // }
;
//添加
Route::post('add_do',"goods\GoodsController@add_do");
//展示
Route::get('list',"goods\GoodsController@Alist");
//删除
Route::post('del',"goods\GoodsController@del");
//修改
Route::any('upd',"goods\GoodsController@upd");
//修改执行
Route::any('upd_do',"goods\GoodsController@upd_do");
//搜索
Route::any('sousuo',"goods\GoodsController@sousuo");
//即点即改
Route::any('doupd',"goods\GoodsController@doupd");


//项目
Route::get('index',"index\IndexController@index");
//注册展示
Route::any('register',"index\IndexController@register");
//登录展示
Route::any('login',"index\IndexController@login");
//我的潮购
Route::any('userpage',"index\IndexController@userpage");
//注册执行
Route::any('register_do',"index\IndexController@register_do");
//登录执行
Route::post('dologin',"index\IndexController@dologin");
//发送验证码
Route::post('send',"index\IndexController@send");
//所有商品
Route::any('goods',"goods\GoodsController@goods");
//商品详情展示
Route::get('content',"goods\GoodsController@content");
//递归
Route::get('getcate',"goods\GoodsController@getcate");
//购物车展示
Route::any('cart',"cart\CartController@cart");
Route::any('zhanshi',"cart\CartController@zhanshi");
//购物车添加
Route::post('docart',"goods\GoodsController@docart");
//删除
Route::post('delcart',"cart\CartController@delcart");
//点击加减失去焦点改变库存
Route::post('doupd',"cart\CartController@doupd");
//订单
Route::any('payment',"payment\PaymentController@payment");
Route::any('order',"payment\PaymentController@order");
//默认地址展示
Route::any('addresses',"payment\PaymentController@addresses");
//添加地址展示
Route::any('address',"payment\PaymentController@address");
//添加地址执行
Route::any('doaddress',"payment\PaymentController@doaddress");
//删除地址
Route::any('dodel',"payment\PaymentController@dodel");
//修改地址
Route::get('upd',"payment\PaymentController@upd");
Route::any('doupd',"payment\PaymentController@doupd");
//修改状态
Route::any('updstatus',"payment\PaymentController@updstatus");
//我的潮购
Route::any('buyrecord',"payment\PaymentController@buyrecord");








